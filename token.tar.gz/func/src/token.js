import { Client, Users, ID, Query } from "node-appwrite";

const client = new Client()
    .setEndpoint('https://cloud.appwrite.io/v1')
    .setProject('667acbf1003d9e20efcc')
    .setKey('0ce4f059436164a2a93958c512a091d623f2d0bd803e44100db988f22288c66f15b4a5cc810013a24aede09920cc10d5a0a62a8dc4236d2fdbf76a3de7142d38550563def6c5dfedd8a5a56a9247b571bba6fe54364cdc2d242893ba83bd2b9bcadda3e15bda51b9ab7a4412c7e0f5d4157a5f33fa330dbce08d7a9427e1a83b');

const users = new Users(client);

// Эта функция должна быть вызвана с сервера
export async function createTelegramToken(telegramUserId, telegramUsername) {
    let userId;
    
    // Проверяем, существует ли пользователь
    try {
        const existingUser = await users.list([
            Query.equal('telegramId', telegramUserId)
        ]);
        
        if (existingUser.total > 0) {
            userId = existingUser.documents[0].$id;
        } else {
            // Создаем нового пользователя, если он не существует
            const newUser = await users.create(
                ID.unique(),
                {
                    telegramId: telegramUserId,
                    name: telegramUsername
                }
            );
            userId = newUser.$id;
        }
    } catch (error) {
        console.error('Error checking/creating user:', error);
        throw error;
    }

    // Создаем токен
    try {
        const token = await users.createToken(userId);
        return { userId, secret: token.secret };
    } catch (error) {
        console.error('Error creating token:', error);
        throw error;
    }
}